# Demo template

A minimal bundled template.
