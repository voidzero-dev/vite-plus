#!/usr/bin/env node
const fs = require('node:fs');
const path = require('node:path');

const dir = process.argv[2] || 'vite-plus-app';
fs.mkdirSync(dir, { recursive: true });
fs.writeFileSync(
  path.join(dir, 'package.json'),
  JSON.stringify(
    {
      name: path.basename(dir),
      private: true,
      type: 'module',
      scripts: { dev: 'vp dev', lint: 'eslint .' },
      devDependencies: { eslint: '^9.0.0', 'vite-plus': 'latest' },
    },
    null,
    2,
  ) + '\n',
);
fs.writeFileSync(path.join(dir, 'eslint.config.js'), 'export default [];\n');
fs.writeFileSync(
  path.join(dir, 'vite.config.ts'),
  "import { defineConfig } from 'vite-plus';\n\nexport default defineConfig({});\n",
);
