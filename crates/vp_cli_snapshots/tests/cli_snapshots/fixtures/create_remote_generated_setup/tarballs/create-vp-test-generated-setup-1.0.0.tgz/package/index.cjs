#!/usr/bin/env node
const { execFileSync } = require('node:child_process');
const fs = require('node:fs');
const path = require('node:path');

const dir = process.argv[2] || 'generated-setup-app';
fs.mkdirSync(path.join(dir, '.vscode'), { recursive: true });
fs.writeFileSync(
  path.join(dir, 'package.json'),
  JSON.stringify(
    {
      name: path.basename(dir),
      private: true,
      type: 'module',
      scripts: { dev: 'vp dev' },
      devDependencies: { 'vite-plus': 'latest' },
    },
    null,
    2,
  ) + '\n',
);
fs.writeFileSync(
  path.join(dir, 'vite.config.ts'),
  "import { defineConfig } from 'vite-plus';\n\nexport default defineConfig({});\n",
);
fs.writeFileSync(path.join(dir, 'AGENTS.md'), '# Template instructions\n');
fs.writeFileSync(
  path.join(dir, '.vscode', 'settings.json'),
  JSON.stringify({ 'editor.tabSize': 2 }, null, 2) + '\n',
);
execFileSync('git', ['init'], { cwd: dir, stdio: 'ignore' });
console.log(`Generated ${dir}`);
