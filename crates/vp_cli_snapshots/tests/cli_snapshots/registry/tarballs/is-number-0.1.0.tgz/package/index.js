

'use strict';

module.exports = function isNumber(n) {
  return n != null && !!(+n+1/1);
};


